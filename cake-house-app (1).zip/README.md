# 🍰 Cake House Corona - Menu App

A mobile-optimized web app for displaying the Cake House Corona dispensary menu, with a backend proxy to bypass CORS restrictions when calling the iHeartJane API.

## 📁 Project Structure

```
cake-house-app/
├── server.js           # Backend proxy server
├── package.json        # Node.js dependencies
├── public/
│   └── index.html     # Frontend web app
└── README.md          # This file
```

## 🚀 Quick Start

### Prerequisites
- Node.js (version 14 or higher)
- npm (comes with Node.js)

### Installation

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start the Server**
   ```bash
   npm start
   ```

3. **Open Your Browser**
   - Visit: `http://localhost:3000`
   - The app will automatically load!

## 📱 Features

- ✅ iOS-optimized mobile design
- ✅ Real-time product search
- ✅ Category filtering (Flower, Vapes, Edibles, etc.)
- ✅ Product details modal with THC/CBD info
- ✅ Connects to iHeartJane API via backend proxy
- ✅ Fallback to sample data if API is unavailable
- ✅ Beautiful Cake House branding

## 🔧 Configuration

### API Settings
Edit `server.js` to update your iHeartJane credentials:

```javascript
const API_CONFIG = {
    storeId: '6699',              // Your store ID
    token: 'rQ6qxkmADEeyqbjqJzrGdkCK',  // Your API token
    baseUrl: 'https://api.iheartjane.com'
};
```

### Port Configuration
By default, the server runs on port 3000. To change it:

```bash
PORT=8080 npm start
```

## 🌐 Deployment Options

### Option 1: Deploy to Heroku (Free)

1. **Install Heroku CLI**
   ```bash
   npm install -g heroku
   ```

2. **Create Heroku App**
   ```bash
   heroku create cake-house-corona
   ```

3. **Deploy**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push heroku main
   ```

4. **Open Your App**
   ```bash
   heroku open
   ```

### Option 2: Deploy to Vercel

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Deploy**
   ```bash
   vercel
   ```

3. Follow the prompts and your app will be live!

### Option 3: Deploy to Your Own Server

1. **Upload files** to your server via FTP/SSH

2. **Install dependencies**
   ```bash
   npm install --production
   ```

3. **Run with PM2** (keeps server running)
   ```bash
   npm install -g pm2
   pm2 start server.js --name "cake-house"
   pm2 save
   ```

4. **Setup Nginx** (optional, for production)
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;
       
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

## 📱 Mobile Setup (iOS)

1. Open the app in Safari on your iPhone
2. Tap the Share button (square with arrow)
3. Scroll down and tap "Add to Home Screen"
4. Give it a name (e.g., "Cake House")
5. Tap "Add"

Now you have a native-feeling app on your home screen!

## 🔍 API Endpoints

### Health Check
```
GET /api/health
```
Returns server status

### Get Products
```
GET /api/products
```
Returns all menu products

Response format:
```json
{
  "success": true,
  "products": [...],
  "source": "iheartjane" or "sample"
}
```

## 🐛 Troubleshooting

### "Cannot GET /"
- Make sure you ran `npm install` first
- Check that the server is running on the correct port

### "API restricted" or CORS errors
- This is expected! The backend proxy handles this
- Make sure you're accessing via `http://localhost:3000` not opening the HTML file directly

### Products not loading
1. Check server logs in the terminal
2. Verify your API token is correct in `server.js`
3. The app will automatically fall back to sample data if the API fails

### Port already in use
```bash
# Find what's using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or use a different port
PORT=8080 npm start
```

## 🛠️ Development

### Run in development mode with auto-reload:
```bash
npm run dev
```

### Testing API endpoints:
```bash
# Health check
curl http://localhost:3000/api/health

# Get products
curl http://localhost:3000/api/products
```

## 📝 Notes

- The backend proxy server handles all communication with iHeartJane API
- Your API token is kept secure on the backend (never exposed to browsers)
- The app works offline after first load (products are cached)
- Sample data is automatically used if the API is unavailable

## 🆘 Support

If you need help:
1. Check the terminal for error messages
2. Verify your iHeartJane API credentials
3. Make sure Node.js is installed: `node --version`
4. Contact iHeartJane support if API issues persist: partnersuccess@iheartjane.com

## 📄 License

MIT License - Feel free to use and modify for your dispensary!

---

**Built with ❤️ for Cake House Corona**
