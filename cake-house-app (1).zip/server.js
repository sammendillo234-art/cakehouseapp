const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = process.env.PORT || 3000;

// iHeartJane API Configuration
const API_CONFIG = {
    storeId: '6699',
    token: 'rQ6qxkmADEeyqbjqJzrGdkCK',
    baseUrl: 'https://api.iheartjane.com'
};

// Enable CORS for all origins (you can restrict this to your domain later)
app.use(cors());
app.use(express.json());

// Serve static files (your HTML app)
app.use(express.static('public'));

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Cake House API Proxy is running' });
});

// Proxy endpoint for fetching products
app.get('/api/products', async (req, res) => {
    console.log('Fetching products from iHeartJane Partner API...');
    
    try {
        let allProducts = [];
        let paginationId = 0;
        const maxPerPage = 500;

        // Use the Partner API endpoint (same as budtender app)
        do {
            const endpoint = `${API_CONFIG.baseUrl}/partner/v1/stores/${API_CONFIG.storeId}/menu_products?visible=true&count=${maxPerPage}&pagination_id=${paginationId}`;
            
            console.log(`Fetching from: ${endpoint}`);
            
            const response = await fetch(endpoint, {
                method: 'GET',
                headers: {
                    'Authorization': `Token ${API_CONFIG.token}`,  // Use "Token" not "Bearer"
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            console.log(`Response status: ${response.status}`);

            if (!response.ok) {
                const errorText = await response.text();
                console.log(`API Error Response: ${errorText}`);
                throw new Error(`API returned status ${response.status}`);
            }

            const data = await response.json();
            console.log(`Received ${data.menu_products?.length || 0} products in this page`);
            
            // Debug: Log first product structure to help troubleshoot
            if (data.menu_products && data.menu_products.length > 0 && paginationId === 0) {
                console.log('Sample product structure:', JSON.stringify(data.menu_products[0], null, 2));
                
                // Log category mappings to debug issues
                console.log('\nCategory mappings (first 10 products):');
                data.menu_products.slice(0, 10).forEach(p => {
                    const rawKind = p.kind || 'none';
                    const kindSubtype = p.kind_subtype || 'none';
                    console.log(`  "${p.name}": kind="${rawKind}", subtype="${kindSubtype}"`);
                });
            }
            
            // Partner API returns { "menu_products": [...] }
            if (data.menu_products && Array.isArray(data.menu_products)) {
                // Transform to our format
                const transformed = data.menu_products.map(item => {
                    // Extract price - iHeartJane uses specific price fields
                    let price = item.price_each || 
                               item.price_gram || 
                               item.price_half_gram ||
                               item.price_eighth_ounce ||
                               item.price_quarter_ounce ||
                               item.price_half_ounce ||
                               item.price_ounce ||
                               item.price_two_gram ||
                               0;
                    
                    // Map categories using 'kind' field
                    let category = item.kind || item.type || 'Other';
                    
                    const categoryMap = {
                        'flower': 'Flower',
                        'flowers': 'Flower',
                        'edible': 'Edibles',
                        'edibles': 'Edibles',
                        'pre-roll': 'Pre-Rolls',
                        'preroll': 'Pre-Rolls',
                        'pre-rolls': 'Pre-Rolls',
                        'prerolls': 'Pre-Rolls',
                        'extract': 'Concentrates',
                        'extracts': 'Concentrates',
                        'concentrate': 'Concentrates',
                        'concentrates': 'Concentrates',
                        'vape': 'Vapes',
                        'vapes': 'Vapes',
                        'vaporizer': 'Vapes',
                        'vaporizers': 'Vapes',
                        'cartridge': 'Vapes',
                        'cartridges': 'Vapes',
                        'topical': 'Topicals',
                        'topicals': 'Topicals',
                        'tincture': 'Tinctures',
                        'tinctures': 'Tinctures',
                        'cbd': 'CBD',
                    };
                    
                    const lowerCategory = category.toLowerCase().trim();
                    category = categoryMap[lowerCategory] || category;
                    
                    // Format THC/CBD percentages - check for null/undefined, not truthiness (0 is valid)
                    let thc = '';
                    let cbd = '';
                    
                    if (item.percent_thc !== null && item.percent_thc !== undefined && item.percent_thc > 0) {
                        thc = `${item.percent_thc}%`;
                    } else if (item.product_percent_thc !== null && item.product_percent_thc !== undefined && item.product_percent_thc > 0) {
                        thc = `${item.product_percent_thc}%`;
                    }
                    
                    if (item.percent_cbd !== null && item.percent_cbd !== undefined && item.percent_cbd > 0) {
                        cbd = `${item.percent_cbd}%`;
                    } else if (item.product_percent_cbd !== null && item.product_percent_cbd !== undefined && item.product_percent_cbd > 0) {
                        cbd = `${item.product_percent_cbd}%`;
                    }
                    
                    return {
                        id: item.id || item.product_id,
                        name: item.name || '',
                        category: category,
                        brand: item.brand || '',
                        price: price,
                        thc: thc,
                        cbd: cbd,
                        description: item.description || '',
                        image: item.image_urls?.[0] || 
                               item.product_photos?.[0]?.urls?.medium ||
                               item.product_photos?.[0]?.urls?.original ||
                               item.photos?.[0]?.urls?.medium ||
                               item.photos?.[0]?.urls?.original ||
                               '',
                        in_stock: item.inventory_count > 0
                    };
                });
                
                allProducts = allProducts.concat(transformed);
            }

            // Check if we should continue pagination
            if (!data.menu_products || data.menu_products.length < maxPerPage) {
                break; // No more pages
            }

            // Set pagination_id to the last product's id
            const lastProduct = data.menu_products[data.menu_products.length - 1];
            if (!lastProduct || !lastProduct.id) {
                break;
            }
            paginationId = lastProduct.id;

        } while (true);

        console.log(`Total products fetched: ${allProducts.length}`);

        if (allProducts.length > 0) {
            res.json({
                success: true,
                products: allProducts,
                source: 'iheartjane',
                count: allProducts.length
            });
        } else {
            console.log('No products returned from API, using sample data');
            res.json({
                success: true,
                products: getSampleProducts(),
                source: 'sample',
                message: 'No products from API - using sample data'
            });
        }

    } catch (error) {
        console.error('Error fetching products:', error);
        res.json({
            success: true,
            products: getSampleProducts(),
            source: 'sample',
            error: error.message,
            message: 'API error - using sample data'
        });
    }
});

// Get sample products as fallback
function getSampleProducts() {
    return [
        {
            id: 1,
            name: 'Blue Dream',
            category: 'Flower',
            brand: 'Premium Cannabis',
            price: 45,
            thc: '22%',
            cbd: '0.5%',
            image: 'https://images.unsplash.com/photo-1605775355881-58c19abd5504?w=400',
            description: 'A sativa-dominant hybrid with sweet berry aroma. Perfect for daytime use with balanced effects.'
        },
        {
            id: 2,
            name: 'OG Kush',
            category: 'Flower',
            brand: 'Top Shelf',
            price: 50,
            thc: '24%',
            cbd: '0.3%',
            image: 'https://images.unsplash.com/photo-1536424877815-6e4e7e0e4e12?w=400',
            description: 'Classic strain with earthy pine and lemon notes. Known for its potent relaxing effects.'
        },
        {
            id: 3,
            name: 'Sour Diesel',
            category: 'Flower',
            brand: 'Premium Cannabis',
            price: 48,
            thc: '21%',
            cbd: '0.4%',
            image: 'https://images.unsplash.com/photo-1605775355880-34a6caa858ca?w=400',
            description: 'Energizing sativa with a pungent diesel aroma. Great for creativity and focus.'
        },
        {
            id: 4,
            name: 'Sunset Sherbet',
            category: 'Flower',
            brand: 'Exotic Gardens',
            price: 55,
            thc: '19%',
            cbd: '0.2%',
            image: 'https://images.unsplash.com/photo-1507358522600-9f71e620c44e?w=400',
            description: 'Indica-dominant with fruity sherbet flavors. Provides full-body relaxation.'
        },
        {
            id: 5,
            name: 'Gelato',
            category: 'Flower',
            brand: 'Top Shelf',
            price: 52,
            thc: '23%',
            cbd: '0.5%',
            image: 'https://images.unsplash.com/photo-1605775355881-37a8dccf8b7d?w=400',
            description: 'Dessert-like strain with sweet and creamy flavor profile. Balanced hybrid effects.'
        },
        {
            id: 6,
            name: 'Live Resin Cart',
            category: 'Vapes',
            brand: 'Extract Labs',
            price: 40,
            thc: '85%',
            cbd: '1%',
            image: 'https://images.unsplash.com/photo-1585333312935-cdf7c859da60?w=400',
            description: 'Premium live resin cartridge with full-spectrum terpenes. Smooth and flavorful.'
        },
        {
            id: 7,
            name: 'Mixed Berry Gummies',
            category: 'Edibles',
            brand: 'Sweet Relief',
            price: 25,
            thc: '10mg/pc',
            cbd: '0mg',
            image: 'https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=400',
            description: '10-pack of delicious mixed berry gummies. 10mg THC per piece, perfect for precise dosing.'
        },
        {
            id: 8,
            name: 'Chocolate Bar',
            category: 'Edibles',
            brand: 'Canna Confections',
            price: 20,
            thc: '100mg',
            cbd: '0mg',
            image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?w=400',
            description: 'Rich dark chocolate infused with high-quality cannabis. 10 pieces, 10mg each.'
        },
        {
            id: 9,
            name: 'CBD Tincture',
            category: 'CBD',
            brand: 'Wellness Co',
            price: 60,
            thc: '0%',
            cbd: '1000mg',
            image: 'https://images.unsplash.com/photo-1601042879364-f3947d3f9c16?w=400',
            description: 'Full-spectrum CBD tincture. 1000mg CBD per bottle. Great for wellness and relaxation.'
        },
        {
            id: 10,
            name: 'Diamonds',
            category: 'Concentrates',
            brand: 'Extract Labs',
            price: 70,
            thc: '99%',
            cbd: '0%',
            image: 'https://images.unsplash.com/photo-1605775355930-f7f4cb17bb4f?w=400',
            description: 'Pure THCA diamonds with natural terpenes. Maximum potency and flavor.'
        },
        {
            id: 11,
            name: 'Pre-Roll Pack',
            category: 'Pre-Rolls',
            brand: 'Ready Roll',
            price: 35,
            thc: '20%',
            cbd: '0.5%',
            image: 'https://images.unsplash.com/photo-1605775355880-34a6cb8a9c6d?w=400',
            description: 'Pack of 5 premium pre-rolls. 1g each, perfect for on-the-go convenience.'
        },
        {
            id: 12,
            name: 'Topical Cream',
            category: 'Topicals',
            brand: 'Relief Remedies',
            price: 45,
            thc: '200mg',
            cbd: '200mg',
            image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400',
            description: 'Soothing topical cream with balanced THC/CBD. Great for localized relief.'
        }
    ];
}

// Start the server
app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   🍰  Cake House Corona API Proxy Server                  ║
║                                                            ║
║   Status: Running                                          ║
║   Port: ${PORT}                                               ║
║   Store ID: ${API_CONFIG.storeId}                                        ║
║                                                            ║
║   Endpoints:                                               ║
║   • GET /api/health    - Health check                     ║
║   • GET /api/products  - Fetch menu products              ║
║                                                            ║
║   Frontend: http://localhost:${PORT}                          ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
    `);
});
